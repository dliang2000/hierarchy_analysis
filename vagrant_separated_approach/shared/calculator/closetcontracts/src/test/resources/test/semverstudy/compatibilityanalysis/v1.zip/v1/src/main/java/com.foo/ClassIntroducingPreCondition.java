package com.foo;
public class ClassIntroducingPreCondition {
    public static void foo(int i) {}
}