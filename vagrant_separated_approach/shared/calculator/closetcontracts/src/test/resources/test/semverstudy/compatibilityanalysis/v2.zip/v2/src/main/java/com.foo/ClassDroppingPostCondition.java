package com.foo;

public class ClassDroppingPostCondition {
    public static Object foo(int i) {
        return "this could be null";
    }
}